=======
Credits
=======

Maintainer
----------

* Jianfeng Chen <jchen37@ncsu.edu>

Contributors
------------

None yet. Why not be the first? See: CONTRIBUTING.rst
