============
Installation
============

At the command line::

    $ pip install git+git://github.com/Ginfung/LACE

Just a kind reminder, the package may be installed into some other folder, which is not included in PYTHONPATH, such as /usr/local/lib/python2.7/site-packages/ . Python can only recongnize the packages in PYTHONPATH or the current working directory. If you come across this situation, please check http://stackoverflow.com/questions/12311085/how-to-permanently-append-a-directory-to-pythonpath .

If you don't know where LACE is installed, just run "pip uninstall lace" . You will get the answer.
